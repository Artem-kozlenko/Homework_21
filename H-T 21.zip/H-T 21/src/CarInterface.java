public interface CarInterface {
    void gas(int Var);

    void brake(int Var);

    void description(String Var1, int Var2, String Var3);
}
